import { useState } from 'react'
import type { Card, Lang } from '../types'

interface Props { userCards: Card[]; onAdd: (c: Card) => void; onDelete: (id: string) => void }

const empty = { sentence: '', target: '', meaning: '', translation: '', ipa: '', pos: '', example: '' }
const field = 'mt-1 w-full rounded-lg border border-ink/20 bg-white px-3 py-2 focus:border-ink'

export default function AddCard({ userCards, onAdd, onDelete }: Props) {
  const [lang, setLang] = useState<Lang>('en')
  const [f, setF] = useState(empty)
  const [error, setError] = useState('')
  const set = (k: keyof typeof empty) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF(s => ({ ...s, [k]: e.target.value }))

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const { sentence, target, meaning, translation } = f
    if (![sentence, target, meaning, translation].every(v => v.trim())) return setError('Hãy điền đủ các ô bắt buộc.')
    if (!sentence.toLowerCase().includes(target.trim().toLowerCase())) return setError('Từ mục tiêu phải xuất hiện nguyên văn trong câu gốc.')
    onAdd({
      id: 'u' + Date.now(), lang, sentence: sentence.trim(), target: target.trim(), translation: translation.trim(),
      word: { meaning: meaning.trim(), ipa: f.ipa.trim() || undefined, pos: f.pos.trim() || undefined, example: f.example.trim() || undefined },
    })
    setF(empty); setError('')
  }

  return (
    <div className="grid gap-8 md:grid-cols-[3fr_2fr]">
      <form onSubmit={submit} className="space-y-4 rounded-2xl bg-white p-6 shadow">
        <h2 className="text-xl font-bold">Thêm thẻ mới</h2>
        <div className="flex gap-2" role="radiogroup" aria-label="Ngôn ngữ">
          {(['en', 'fr'] as Lang[]).map(l => (
            <button key={l} type="button" role="radio" aria-checked={lang === l} onClick={() => setLang(l)}
              className={`rounded-full border px-4 py-1 text-sm ${lang === l ? 'border-ink bg-ink text-white' : 'border-ink/20'}`}>
              {l === 'en' ? 'Tiếng Anh' : 'Tiếng Pháp'}
            </button>
          ))}
        </div>
        <label className="block text-sm font-medium">Câu gốc *<textarea rows={2} lang={lang} className={field} value={f.sentence} onChange={set('sentence')} /></label>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block text-sm font-medium">Từ mục tiêu * <span className="font-normal text-ink/50">(có trong câu)</span><input className={field} value={f.target} onChange={set('target')} /></label>
          <label className="block text-sm font-medium">Nghĩa của từ *<input className={field} value={f.meaning} onChange={set('meaning')} /></label>
        </div>
        <label className="block text-sm font-medium">Nghĩa cả câu (Tiếng Việt) *<textarea rows={2} className={field} value={f.translation} onChange={set('translation')} /></label>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block text-sm font-medium">Phiên âm<input className={field} value={f.ipa} onChange={set('ipa')} placeholder="/ˈsæmpl/" /></label>
          <label className="block text-sm font-medium">Loại từ<input className={field} value={f.pos} onChange={set('pos')} placeholder="danh từ" /></label>
        </div>
        <label className="block text-sm font-medium">Ví dụ ngắn<input lang={lang} className={field} value={f.example} onChange={set('example')} /></label>
        {error && <p role="alert" className="text-sm font-medium text-fr">{error}</p>}
        <button className="rounded-lg bg-ink px-5 py-2 font-medium text-white hover:bg-ink/85">Lưu thẻ</button>
      </form>

      <section className="rounded-2xl bg-white p-6 shadow">
        <h2 className="text-xl font-bold">Thẻ của bạn ({userCards.length})</h2>
        {userCards.length === 0 ? <p className="mt-3 text-sm text-ink/60">Chưa có thẻ nào. Điền biểu mẫu bên cạnh để tạo thẻ đầu tiên.</p> : (
          <ul className="mt-3 divide-y divide-ink/10">
            {userCards.map(c => (
              <li key={c.id} className="flex items-start justify-between gap-3 py-3 text-sm">
                <div><p lang={c.lang} className="font-serif">{c.sentence}</p><p className="text-ink/60">{c.target} — {c.word.meaning}</p></div>
                <button onClick={() => onDelete(c.id)} className="shrink-0 text-fr hover:underline">Xóa</button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
