import { Fragment, useEffect, useMemo, useRef, useState } from 'react'
import type { Filter, Lang } from '../types'
import { KIND_LABEL, ROOTS, formOf, langsOf, searchRoots, type Hit } from '../lib/roots'

type Accent = 'en-US' | 'en-GB'
interface Props {
  filter: Filter
  onFilter: (f: Filter) => void
  accent: Accent
  onAccent: (a: Accent) => void
  onSpeak: (text: string, lang: Lang) => void
  speakOk: boolean
  focusId: string | null
  onClearFocus: () => void
}

const FILTERS: [Filter, string][] = [['all', 'Tất cả'], ['en', 'Tiếng Anh (EN)'], ['fr', 'Tiếng Pháp (FR)']]
const tone = (l: Lang) => (l === 'fr' ? { text: 'text-fr', chip: 'bg-fr', ring: 'border-fr' } : { text: 'text-en', chip: 'bg-en', ring: 'border-en' })

export default function RootsPage(p: Props) {
  const [query, setQuery] = useState('')
  const input = useRef<HTMLInputElement>(null)
  const focused = p.focusId ? ROOTS.find(r => r.id === p.focusId) : undefined
  const hits = useMemo<Hit[]>(() => (focused ? [{ root: focused, score: 0 }] : searchRoots(query, p.filter)), [focused, query, p.filter])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(t.tagName)) { e.preventDefault(); input.current?.focus() }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <section>
      <div className="relative">
        <input
          ref={input}
          type="text"
          value={query}
          onChange={e => { setQuery(e.target.value); if (p.focusId) p.onClearFocus() }}
          placeholder="Tìm gốc từ, tiền tố, nghĩa hoặc một từ… (vd: spect, anti-, nhìn, inspection)"
          aria-label="Tra cứu gốc từ và ghép từ"
          className="w-full rounded-xl border border-ink/20 bg-white px-4 py-3 pr-10 text-base focus:border-ink"
        />
        {query && (
          <button type="button" aria-label="Xóa tìm kiếm" onClick={() => { setQuery(''); input.current?.focus() }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xl text-ink/50 hover:text-ink">×</button>
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-2" role="radiogroup" aria-label="Lọc ngôn ngữ">
          {FILTERS.map(([k, l]) => (
            <button key={k} role="radio" aria-checked={p.filter === k} onClick={() => p.onFilter(k)}
              className={`rounded-full border px-4 py-1 text-sm ${p.filter === k ? 'border-ink bg-ink text-white' : 'border-ink/20 bg-white'}`}>{l}</button>
          ))}
        </div>
        {p.filter !== 'fr' && (
          <label className="text-sm">Giọng Anh{' '}
            <select value={p.accent} onChange={e => p.onAccent(e.target.value as Accent)} className="rounded border border-ink/20 bg-white px-2 py-1">
              <option value="en-US">en-US (Mỹ)</option><option value="en-GB">en-GB (Anh)</option>
            </select>
          </label>
        )}
      </div>

      {focused ? (
        <p className="mt-4 rounded-lg bg-white px-4 py-2 text-sm shadow-sm">
          Đang xem gốc từ của thẻ bạn vừa mở.{' '}
          <button onClick={() => { p.onClearFocus(); setQuery('') }} className="underline">Xem tất cả gốc từ</button>
        </p>
      ) : (
        <p aria-live="polite" className="mt-4 text-sm text-ink/60">{query ? `${hits.length} kết quả cho “${query}”` : `${hits.length} mục`} · nhấn “/” để tìm nhanh</p>
      )}

      <div className="mt-3 space-y-5">
        {hits.map(h => <RootCard key={h.root.id} hit={h} filter={p.filter} onSpeak={p.onSpeak} speakOk={p.speakOk} />)}
        {hits.length === 0 && (
          <div className="rounded-2xl bg-white p-8 text-center shadow">
            <p className="font-bold">Không tìm thấy kết quả.</p>
            <p className="mt-1 text-sm text-ink/60">Thử gõ ngắn hơn (vd “spect”), bỏ dấu, hoặc tìm theo nghĩa Tiếng Việt (vd “nhìn”, “viết”).</p>
          </div>
        )}
      </div>
    </section>
  )
}

function RootCard({ hit, filter, onSpeak, speakOk }: { hit: Hit; filter: Filter; onSpeak: Props['onSpeak']; speakOk: boolean }) {
  const r = hit.root
  const langs = langsOf(r, filter)
  return (
    <article className="rounded-2xl bg-white p-5 shadow sm:p-6">
      <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
        <span className="rounded bg-ink px-2 py-0.5 text-white">{KIND_LABEL[r.kind]}</span>
        {langs.map(l => <span key={l} className={`rounded px-2 py-0.5 text-white ${tone(l).chip}`}>{l.toUpperCase()}</span>)}
      </div>
      <h2 className="mt-2 font-serif text-3xl">{formOf(r, langs)}</h2>
      <p className="mt-2 text-sm"><span className="text-ink/60">{r.origin}</span> · nghĩa cốt lõi: <b>{r.meaning}</b></p>
      {r.note && <p className="mt-1 text-sm text-ink/60">{r.note}</p>}
      {hit.hint && <p className="mt-3 rounded-lg bg-paper px-3 py-2 text-sm"><b>Khớp với từ bạn gõ:</b> {hit.hint}</p>}

      <div className="mt-4 space-y-3">
        {langs.map(l => {
          const f = r.formula[l]
          if (!f) return null
          return (
            <div key={l} className="flex flex-wrap items-center gap-2">
              <span className={`w-7 text-xs font-bold ${tone(l).text}`}>{l.toUpperCase()}</span>
              {f.parts.map(([t, g], i) => (
                <Fragment key={i}>
                  {i > 0 && <span className="text-ink/50">+</span>}
                  <span className="rounded-lg bg-paper px-3 py-1.5 text-center">
                    <span lang={l} className="block font-serif text-lg leading-tight">{t}</span>
                    <span className="block text-xs text-ink/60">{g}</span>
                  </span>
                </Fragment>
              ))}
              <span className="text-ink/50">=</span>
              <button type="button" disabled={!speakOk} onClick={() => onSpeak(f.result, l)} aria-label={`Nghe phát âm ${f.result}`}
                title={speakOk ? 'Nghe phát âm' : 'Trình duyệt không hỗ trợ phát âm'}
                className={`rounded-lg border-2 px-3 py-1.5 font-serif text-lg font-medium hover:bg-paper disabled:cursor-not-allowed disabled:opacity-60 ${tone(l).text} ${tone(l).ring}`}>
                {f.result} 🔊
              </button>
              <span className="text-sm">→ <i>{f.meaning}</i></span>
            </div>
          )
        })}
      </div>

      <div className={`mt-5 grid gap-5 ${langs.length > 1 ? 'md:grid-cols-2' : ''}`}>
        {langs.map(l => (
          <div key={l}>
            <h3 className={`text-xs font-bold ${tone(l).text}`}>Từ phái sinh · {l === 'en' ? 'Tiếng Anh' : 'Tiếng Pháp'}</h3>
            <ul className="mt-1 divide-y divide-ink/10">
              {(r.words[l] ?? []).map(([w, parts, meaning]) => (
                <li key={w} className="flex items-start gap-2 py-2">
                  <button type="button" disabled={!speakOk} onClick={() => onSpeak(w, l)} aria-label={`Nghe phát âm ${w}`}
                    title={speakOk ? 'Nghe phát âm' : 'Trình duyệt không hỗ trợ phát âm'}
                    className="shrink-0 rounded-full border border-ink/20 px-2 py-0.5 text-xs hover:bg-ink hover:text-white disabled:cursor-not-allowed disabled:opacity-40">🔊</button>
                  <div className="text-sm">
                    <span lang={l} className="font-serif text-base font-medium">{w}</span> <span className="text-ink/50">({parts})</span>
                    <p>{meaning}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </article>
  )
}
