import { useState } from 'react'
import type { Card, Root } from '../types'

interface Props {
  card: Card
  flipped: boolean
  onFlip: () => void
  onSpeak: (text: string) => void
  speakOk: boolean
  roots: Root[]
  onOpenRoot: (id: string) => void
}

export default function Flashcard({ card, flipped, onFlip, onSpeak, speakOk, roots, onOpenRoot }: Props) {
  const [peek, setPeek] = useState(false)
  const fr = card.lang === 'fr'
  const tone = fr
    ? { text: 'text-fr', mark: 'bg-fr/15 border-fr', chip: 'bg-fr', edge: 'border-t-fr' }
    : { text: 'text-en', mark: 'bg-en/15 border-en', chip: 'bg-en', edge: 'border-t-en' }

  const i = card.sentence.toLowerCase().indexOf(card.target.toLowerCase())
  const parts = i < 0 ? null : [card.sentence.slice(0, i), card.sentence.slice(i, i + card.target.length), card.sentence.slice(i + card.target.length)]

  const stop = (fn: () => void) => (e: React.MouseEvent) => { e.stopPropagation(); fn() }

  const sentence = (size: string) => (
    <p lang={card.lang} className={`font-serif leading-snug ${size}`}>
      {parts ? (
        <>
          {parts[0]}
          <button
            type="button"
            onClick={stop(() => setPeek(p => !p))}
            onMouseEnter={() => setPeek(true)}
            onMouseLeave={() => setPeek(false)}
            className={`mx-px rounded-sm border-b-2 px-1 ${tone.mark}`}
            aria-label={`Xem nghĩa của từ ${card.target}`}
          >{parts[1]}</button>
          {parts[2]}
        </>
      ) : card.sentence}
    </p>
  )

  const wordInfo = (
    <div className="rounded-lg bg-paper px-4 py-3 text-left text-sm">
      <p className="flex flex-wrap items-baseline gap-x-2">
        <span className={`font-serif text-lg font-medium ${tone.text}`}>{card.target}</span>
        {card.word.ipa && <span className="text-ink/60">{card.word.ipa}</span>}
        {card.word.pos && <span className="italic text-ink/60">{card.word.pos}</span>}
      </p>
      <p className="mt-1 font-medium">{card.word.meaning}</p>
      {card.word.example && <p className="mt-1 text-ink/70">Ví dụ: <span lang={card.lang} className="font-serif">{card.word.example}</span></p>}
    </div>
  )

  const speakBtn = (text: string, label: string) => (
    <button
      type="button"
      disabled={!speakOk}
      onClick={stop(() => onSpeak(text))}
      title={speakOk ? 'Nghe phát âm (P)' : 'Trình duyệt không hỗ trợ phát âm'}
      className="rounded-full border border-ink/20 px-3 py-1 text-sm hover:bg-ink hover:text-white disabled:cursor-not-allowed disabled:opacity-40"
    >🔊 {label}</button>
  )

  const rootBadges = roots.length > 0 && (
    <div className="mt-3 flex flex-wrap gap-2">
      {roots.map(r => (
        <button key={r.id} type="button" onClick={stop(() => onOpenRoot(r.id))} title="Xem cách ghép từ"
          className={`rounded-full border border-current px-3 py-1 text-xs font-medium hover:bg-ink hover:text-white ${tone.text}`}>
          🌱 Xem gốc từ: {r.form[card.lang]}
        </button>
      ))}
    </div>
  )

  return (
    <div className="scene">
      <div className={`flip ${flipped ? 'on' : ''}`}>
        <div
          onClick={onFlip}
          className={`face ${flipped ? 'pointer-events-none' : ''} min-h-[20rem] cursor-pointer rounded-2xl border-t-8 bg-white p-6 shadow-lg sm:p-10 ${tone.edge}`}
        >
          <div className="flex items-center justify-between">
            <span className={`rounded px-2 py-0.5 text-xs font-bold text-white ${tone.chip}`}>{fr ? 'Français' : 'English'}</span>
            {speakBtn(card.sentence, 'Nghe câu')}
          </div>
          <div className="mt-8">{sentence('text-3xl sm:text-4xl')}</div>
          <div className="mt-6 min-h-[5.5rem]">
            {peek ? wordInfo : <p className="text-sm text-ink/50">Chạm hoặc rê chuột vào từ được tô để xem nghĩa. Nhấn Space để lật thẻ.</p>}
            {rootBadges}
          </div>
        </div>

        <div
          onClick={onFlip}
          className={`face back ${flipped ? '' : 'pointer-events-none'} min-h-[20rem] cursor-pointer rounded-2xl border-t-8 border-t-ink bg-white p-6 shadow-lg sm:p-10`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-ink/50">Nghĩa tiếng Việt</span>
            {speakBtn(card.sentence, 'Nghe câu')}
          </div>
          <p className="mt-6 font-serif text-2xl leading-snug sm:text-3xl">{card.translation}</p>
          <p lang={card.lang} className="mt-3 font-serif text-base text-ink/60">{card.sentence}</p>
          <div className="mt-5 flex items-start gap-3">
            <div className="flex-1">{wordInfo}{rootBadges}</div>
            {speakBtn(card.target, 'Từ')}
          </div>
        </div>
      </div>
    </div>
  )
}
