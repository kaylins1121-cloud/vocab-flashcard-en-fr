import type { Level, Progress } from '../types'

const MIN = 60_000
const DAY = 86_400_000

/** SRS đơn giản: Khó → ôn lại sau 10 phút; Tạm → ×1,6 (tối thiểu 1 ngày); Dễ → ×2,5 (tối thiểu 3 ngày). */
export function review(prev: Progress | undefined, level: Level): Progress {
  const now = Date.now()
  const base = prev?.interval ?? 0
  let interval = 0
  let dueAt = now + 10 * MIN
  if (level === 'ok') { interval = Math.max(1, Math.round(base * 1.6)); dueAt = now + interval * DAY }
  if (level === 'easy') { interval = Math.max(3, Math.round(base * 2.5)); dueAt = now + interval * DAY }
  return { reviews: (prev?.reviews ?? 0) + 1, level, interval, dueAt }
}

export const isDue = (p?: Progress) => !p || p.dueAt <= Date.now()

export function nextLabel(p: Progress): string {
  const ms = p.dueAt - Date.now()
  if (ms <= 0) return 'đến hạn'
  if (ms < 60 * MIN) return `${Math.ceil(ms / MIN)} phút nữa`
  if (ms < DAY) return `${Math.round(ms / (60 * MIN))} giờ nữa`
  return `${Math.round(ms / DAY)} ngày nữa`
}
