import data from '../data/wordRoots.json'
import type { Filter, Lang, Root, RootKind } from '../types'

export const ROOTS = data as unknown as Root[]
export const KIND_LABEL: Record<RootKind, string> = { root: 'Gốc từ', prefix: 'Tiền tố', suffix: 'Hậu tố' }
const KIND_KEYWORDS: Record<RootKind, string> = { root: 'gốc từ root', prefix: 'tiền tố prefix', suffix: 'hậu tố suffix' }

/** Chuẩn hóa để so khớp: bỏ dấu, hạ chữ thường, bỏ ký tự đặc biệt ("anti-" → "anti"). */
export const norm = (s: string) =>
  s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/đ/g, 'd').replace(/[^a-z0-9]+/g, ' ').trim()

export const langsOf = (r: Root, filter: Filter): Lang[] => r.langs.filter(l => filter === 'all' || l === filter)

export function formOf(r: Root, langs: Lang[]): string {
  const forms = langs.flatMap(l => (r.form[l] ?? '').split(' / ')).filter(Boolean)
  return forms.filter((f, i) => forms.indexOf(f) === i).join(' / ')
}

export interface Hit { root: Root; score: number; hint?: string }

/** Tra cứu theo gốc/tiền tố/hậu tố, nghĩa Việt, từ phái sinh, hoặc một từ bất kỳ (tách cấu tạo). */
export function searchRoots(query: string, filter: Filter): Hit[] {
  const pool = ROOTS.filter(r => langsOf(r, filter).length > 0)
  const q = norm(query)
  if (!q) return pool.map(root => ({ root, score: 0 }))

  const hits: Hit[] = []
  for (const root of pool) {
    let score = 0
    let hint: string | undefined
    const hit = (s: number, h?: string) => { if (s > score) { score = s; hint = h } }
    const has = (t: string) => norm(t).includes(q)
    const eq = (t: string) => norm(t) === q

    if (norm(root.id) === q) hit(10)
    for (const l of langsOf(root, filter)) {
      const forms = (root.form[l] ?? '').split('/').map(norm)
      if (forms.some(f => f === q)) hit(10)
      else if (forms.some(f => f.includes(q))) hit(6)

      for (const [w, p, m] of root.words[l] ?? []) {
        if (eq(w)) hit(9, `${w} = ${p} → ${m}`)
        else if (has(w)) hit(4)
        else if (has(p) || has(m)) hit(3)
      }
      const f = root.formula[l]
      if (f) {
        const desc = `${f.result} = ${f.parts.map(([t]) => t).join(' + ')} → ${f.meaning}`
        if (eq(f.result)) hit(8, desc)
        else if (has(f.result)) hit(4)
        else if (f.parts.some(([t]) => eq(t))) hit(6)
        else if (has(f.meaning) || f.parts.some(([, g]) => has(g))) hit(3)
      }
    }
    if (has(root.meaning) || has(root.origin)) hit(3)
    if (has(KIND_KEYWORDS[root.kind])) hit(2)
    if (root.note && has(root.note)) hit(1)

    // Tách cấu tạo của một từ bất kỳ (vd "inspection" chứa "spect")
    if (!q.includes(' ') && q.length >= 4) {
      const f = root.frag.find(f =>
        root.kind === 'root' ? q.includes(f)
        : root.kind === 'prefix' ? q.startsWith(f) && q.length >= f.length + 3
        : q.endsWith(f) && q.length >= f.length + 2)
      if (f) hit(5, `“${query.trim()}” có thể chứa “${f}” (${root.meaning})`)
    }
    if (score > 0) hits.push({ root, score, hint })
  }
  return hits.sort((a, b) => b.score - a.score)
}

/** Nhận diện chặt cho flashcard: từ phải nằm trong danh sách phái sinh/công thức, hoặc là từ dài kết thúc bằng hậu tố. */
export function rootsForWord(text: string, lang: Lang): Root[] {
  const n = norm(text)
  if (!n) return []
  const cands = [n, ...n.split(' ')]
  return ROOTS.filter(r => {
    if (!r.langs.includes(lang)) return false
    if ((r.words[lang] ?? []).some(([w]) => cands.includes(norm(w)))) return true
    const f = r.formula[lang]
    if (f && cands.includes(norm(f.result))) return true
    return r.kind === 'suffix' && r.frag.some(s => cands.some(c => c.endsWith(s) && c.length >= s.length + 4))
  })
}
