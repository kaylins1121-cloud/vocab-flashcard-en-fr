export type SpeechLang = 'en-US' | 'en-GB' | 'fr-FR'

export const canSpeak = () => typeof window !== 'undefined' && 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window

export function speak(text: string, lang: SpeechLang, rate = 0.9): boolean {
  if (!canSpeak()) return false
  const synth = window.speechSynthesis
  synth.cancel()
  const u = new SpeechSynthesisUtterance(text)
  u.lang = lang
  u.rate = rate
  const voices = synth.getVoices()
  const norm = (l: string) => l.replace('_', '-').toLowerCase()
  const voice = voices.find(v => norm(v.lang) === lang.toLowerCase()) ?? voices.find(v => norm(v.lang).startsWith(lang.slice(0, 2)))
  if (voice) u.voice = voice
  synth.speak(u)
  return true
}
