import { useCallback, useEffect, useMemo, useState } from 'react'
import seed from './data/cards.json'
import type { Card, Filter, Lang, Level, Progress } from './types'
import { load, save } from './lib/storage'
import { isDue, nextLabel, review } from './lib/srs'
import { canSpeak, speak, type SpeechLang } from './lib/speech'
import Flashcard from './components/Flashcard'
import AddCard from './components/AddCard'
import RootsPage from './components/RootsPage'
import { rootsForWord } from './lib/roots'

type Accent = 'en-US' | 'en-GB'
const seedCards = seed as Card[]
const FILTERS: [Filter, string][] = [['all', 'Tất cả'], ['en', 'Tiếng Anh'], ['fr', 'Tiếng Pháp']]
const RATINGS: { level: Level; label: string; key: string; cls: string }[] = [
  { level: 'hard', label: 'Khó', key: '1', cls: 'bg-fr text-white' },
  { level: 'ok', label: 'Tạm', key: '2', cls: 'bg-ink text-white' },
  { level: 'easy', label: 'Dễ', key: '3', cls: 'bg-en text-white' },
]

export default function App() {
  const [userCards, setUserCards] = useState<Card[]>(() => load('lexi.cards', []))
  const [progress, setProgress] = useState<Record<string, Progress>>(() => load('lexi.progress', {}))
  const [accent, setAccent] = useState<Accent>(() => load('lexi.accent', 'en-US'))
  const [filter, setFilter] = useState<Filter>('all')
  const [studyAll, setStudyAll] = useState(false)
  const [tab, setTab] = useState<'study' | 'roots' | 'add'>('study')
  const [flipped, setFlipped] = useState(false)
  const [offset, setOffset] = useState(0)
  const [last, setLast] = useState('')
  const [focusRoot, setFocusRoot] = useState<string | null>(null)
  const speakOk = canSpeak()

  useEffect(() => save('lexi.cards', userCards), [userCards])
  useEffect(() => save('lexi.progress', progress), [progress])
  useEffect(() => save('lexi.accent', accent), [accent])
  useEffect(() => { setFlipped(false); setOffset(0) }, [filter, studyAll])

  const pool = useMemo(() => [...seedCards, ...userCards].filter(c => filter === 'all' || c.lang === filter), [userCards, filter])
  const queue = useMemo(() => {
    if (studyAll) return pool
    const key = (c: Card) => progress[c.id]?.dueAt ?? Number.MAX_SAFE_INTEGER // thẻ đến hạn trước, thẻ mới sau
    return pool.filter(c => isDue(progress[c.id])).sort((a, b) => key(a) - key(b))
  }, [pool, progress, studyAll])
  const current = queue.length ? queue[offset % queue.length] : undefined
  const dueCount = pool.filter(c => isDue(progress[c.id])).length
  const learned = pool.filter(c => progress[c.id]?.reviews).length
  const cardRoots = useMemo(() => (current ? rootsForWord(current.target, current.lang) : []), [current])

  const say = useCallback((text: string) => {
    if (!current) return
    speak(text, current.lang === 'fr' ? 'fr-FR' : (accent as SpeechLang))
  }, [current, accent])

  const speakWord = useCallback((text: string, lang: Lang) => {
    speak(text, lang === 'fr' ? 'fr-FR' : (accent as SpeechLang))
  }, [accent])

  const rate = useCallback((level: Level) => {
    if (!current || !flipped) return
    const next = review(progress[current.id], level)
    setProgress(p => ({ ...p, [current.id]: next }))
    setLast(`Đã lưu — ôn lại ${nextLabel(next)}`)
    setFlipped(false)
    if (studyAll) setOffset(o => o + 1)
  }, [current, flipped, progress, studyAll])

  const skip = useCallback(() => { setFlipped(false); setOffset(o => o + 1) }, [])

  useEffect(() => {
    if (tab !== 'study') return
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(t.tagName) || e.metaKey || e.ctrlKey) return
      if (e.key === ' ' || e.key === 'Enter' || e.key === 'ArrowUp' || e.key === 'ArrowDown') { if (t.tagName === 'BUTTON' && e.key !== ' ') return; e.preventDefault(); setFlipped(f => !f) }
      else if (e.key === 'ArrowRight') skip()
      else if (e.key === '1') rate('hard')
      else if (e.key === '2') rate('ok')
      else if (e.key === '3') rate('easy')
      else if (e.key.toLowerCase() === 'p' && current) say(flipped ? current.target : current.sentence)
    }
    // Tránh phím Space kích hoạt thêm nút đang được focus (lật thẻ 2 lần)
    const onKeyUp = (e: KeyboardEvent) => { if (e.key === ' ' && (e.target as HTMLElement).tagName === 'BUTTON') e.preventDefault() }
    window.addEventListener('keydown', onKey)
    window.addEventListener('keyup', onKeyUp)
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('keyup', onKeyUp) }
  }, [tab, rate, skip, say, current, flipped])

  const resetProgress = () => { if (confirm('Xóa toàn bộ tiến độ học?')) { setProgress({}); setLast('') } }

  return (
    <div className="mx-auto min-h-screen max-w-4xl px-4 py-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">Lexi <span className="font-normal text-ink/50">Anh · Pháp theo câu</span></h1>
        <nav className="flex flex-wrap gap-1 rounded-full bg-white p-1 shadow-sm" aria-label="Chế độ">
          {([['study', 'Học Flashcard'], ['roots', 'Gốc từ & Ghép từ'], ['add', 'Thêm thẻ']] as const).map(([k, l]) => (
            <button key={k} onClick={() => { setTab(k); if (k !== 'roots') setFocusRoot(null) }} aria-current={tab === k ? 'page' : undefined} className={`rounded-full px-4 py-1 text-sm ${tab === k ? 'bg-ink text-white' : ''}`}>{l}</button>
          ))}
        </nav>
      </header>

      {tab === 'roots' ? (
        <main className="mt-6">
          <RootsPage filter={filter} onFilter={setFilter} accent={accent} onAccent={setAccent} onSpeak={speakWord} speakOk={speakOk} focusId={focusRoot} onClearFocus={() => setFocusRoot(null)} />
        </main>
      ) : tab === 'add' ? (
        <main className="mt-6">
          <AddCard userCards={userCards} onAdd={c => setUserCards(u => [...u, c])} onDelete={id => setUserCards(u => u.filter(c => c.id !== id))} />
        </main>
      ) : (
        <main className="mt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex gap-2" role="radiogroup" aria-label="Lọc ngôn ngữ">
              {FILTERS.map(([k, l]) => (
                <button key={k} role="radio" aria-checked={filter === k} onClick={() => setFilter(k)}
                  className={`rounded-full border px-4 py-1 text-sm ${filter === k ? 'border-ink bg-ink text-white' : 'border-ink/20 bg-white'}`}>{l}</button>
              ))}
            </div>
            {filter !== 'fr' && (
              <label className="text-sm">Giọng Anh{' '}
                <select value={accent} onChange={e => setAccent(e.target.value as Accent)} className="rounded border border-ink/20 bg-white px-2 py-1">
                  <option value="en-US">en-US (Mỹ)</option><option value="en-GB">en-GB (Anh)</option>
                </select>
              </label>
            )}
          </div>

          <p className="mt-4 text-sm text-ink/70">
            Đến hạn: <b>{dueCount}</b> · Đã học: <b>{learned}</b>/{pool.length}
            {' · '}
            <button onClick={() => setStudyAll(s => !s)} className="underline">{studyAll ? 'Chỉ ôn thẻ đến hạn' : 'Học tất cả thẻ'}</button>
          </p>
          {!speakOk && <p className="mt-2 rounded bg-fr/10 px-3 py-2 text-sm text-fr">Trình duyệt này không hỗ trợ phát âm (speechSynthesis). Bạn vẫn học bình thường, chỉ không nghe được.</p>}

          <div className="mt-4">
            {current ? (
              <Flashcard key={current.id} card={current} flipped={flipped} onFlip={() => setFlipped(f => !f)} onSpeak={say} speakOk={speakOk} roots={cardRoots} onOpenRoot={id => { setFocusRoot(id); setTab('roots') }} />
            ) : (
              <div className="rounded-2xl bg-white p-10 text-center shadow">
                <p className="text-xl font-bold">Hôm nay bạn đã ôn xong.</p>
                <p className="mt-2 text-ink/70">Không còn thẻ nào đến hạn trong bộ lọc này.</p>
                <button onClick={() => setStudyAll(true)} className="mt-5 rounded-lg bg-ink px-5 py-2 text-white">Học tất cả thẻ</button>
              </div>
            )}
          </div>

          {current && (
            <>
              <div className="mt-5 flex items-center justify-between gap-3">
                <button onClick={() => setFlipped(f => !f)} className="rounded-lg border border-ink/30 bg-white px-5 py-2 font-medium">Lật thẻ</button>
                <div className="flex gap-2">
                  {RATINGS.map(r => (
                    <button key={r.level} disabled={!flipped} onClick={() => rate(r.level)}
                      className={`rounded-lg px-5 py-2 font-medium disabled:opacity-30 ${r.cls}`}>{r.label} <span className="text-xs opacity-70">({r.key})</span></button>
                  ))}
                </div>
                <button onClick={skip} className="text-sm underline">Bỏ qua</button>
              </div>
              <p aria-live="polite" className="mt-3 min-h-[1.25rem] text-sm text-ink/60">{last}</p>
              <p className="mt-4 text-xs text-ink/50">Phím tắt: Space/Enter/↑↓ lật thẻ · 1 Khó · 2 Tạm · 3 Dễ · → bỏ qua · P nghe</p>
            </>
          )}
          <button onClick={resetProgress} className="mt-8 text-xs text-ink/50 underline">Xóa tiến độ học</button>
        </main>
      )}
    </div>
  )
}
