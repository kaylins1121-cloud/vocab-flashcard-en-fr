export type Lang = 'en' | 'fr'
export type Level = 'hard' | 'ok' | 'easy'

export interface Card {
  id: string
  lang: Lang
  sentence: string      // câu gốc (EN hoặc FR)
  target: string        // từ mục tiêu — phải xuất hiện trong câu
  translation: string   // nghĩa cả câu (Tiếng Việt)
  word: { meaning: string; ipa?: string; pos?: string; example?: string }
}

export interface Progress {
  reviews: number       // số lần ôn
  level: Level          // mức nhớ lần gần nhất
  interval: number      // khoảng cách ôn hiện tại (ngày)
  dueAt: number         // timestamp ôn tiếp theo
}

export type Filter = 'all' | Lang

// ---- Gốc từ & Ghép từ ----
export type RootKind = 'root' | 'prefix' | 'suffix'
export type Part = [text: string, gloss: string]                         // ["in-", "vào trong"]
export type DerivedWord = [word: string, parts: string, meaning: string] // ["inspect", "in- + spect", "kiểm tra"]
export interface Formula { parts: Part[]; result: string; meaning: string }
export interface Root {
  id: string
  kind: RootKind
  langs: Lang[]                         // ngôn ngữ có mục này
  form: Partial<Record<Lang, string>>   // dạng hiển thị, vd "pre-" (EN) / "pré-" (FR)
  origin: string                        // nguồn gốc (Latin, Hy Lạp...)
  meaning: string                       // nghĩa cốt lõi (Tiếng Việt)
  note?: string
  frag: string[]                        // đoạn không dấu dùng để nhận diện từ bất kỳ khi tra cứu
  formula: Partial<Record<Lang, Formula>>
  words: Partial<Record<Lang, DerivedWord[]>>
}
